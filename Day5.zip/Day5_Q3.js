// Question 3:
// Using promises/async await/fetch get the random todos from the json placeholder api. And log all the
// completed todos to the console.
// API Endpoint : https://jsonplaceholder.typicode.com/todos


function fetchTodo(){
    fetch("https://jsonplaceholder.typicode.com/todos").then(response=>{console.log(response)
     return response.json()})
     .then(var1=>{
         console.log(var1);
         for(let i=0;i<var1.length;i++){
             if(var1[i].completed==true){
                 console.log(var1[i]);
             }
         }
        })
     .catch(error=>console.log(error))

}
fetchTodo();