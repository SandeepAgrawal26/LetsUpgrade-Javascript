// Question 1:
// Write a program which does the following things:
// 1. Takes a positive number from the user.
// 2. Makes an array of numbers till the number given by user
// 3. Use higher order function to filter the odd numbers
// // 4. Generate and array of the cubes of the filtered numbers

var userInput = parseInt(prompt("Enter any postive number"));
var arr= [];

for (let i = 0; i< userInput;i++){
    
    arr.push(i);
   
    //console.log(arr)  
}
console.log(`Array of the input number is: ${arr}`);

let odd = arr.filter(el=>el%2!=0);
console.log(`Odd number of arrays are: ${odd}`);


let cubegenerator = arr.filter(el=>el%2!=0).map(el=>el**3);
console.log(`Cube of the Odd number of arrays are: ${cubegenerator}`);