// Create a Class User with properties as name, age & email.
// He can login and logout
// Create another class Moderator which has all the features of User, plus additional functionality to Add
// coins and remove coins.
// Create one more class Admin which has all the features of Moderator plus additional features like add a
// Course and delete a particular course for a user

class User {
    constructor(name, age,email) {
      this.name = name;
      this.age = age;
      this.email = email;
      this.coins=0;
      this.courses = [];
    }  
    login(){
        console.log(`${this.name} has logged in`);
        return this;
      }
    logout(){
        console.log(`${this.name} has logged out`);
        return this;
    }
}

class Moderator extends User{
    addCoins(){
    this.coins++;
    console.log(`${this.name} has ${this.coins} coins`);
    return this.coins;
    }
    removeCoins(){
        if(this.coins==0)
        console.log(`${this.name} has no coins`)
        else{
        this.coins--;
        console.log(`${this.name} has ${this.coins} coins`);
        return this.coins;
        }
    }
}

class Admin extends Moderator{
    addCourse(user,course){
        user.courses.push(course);
        console.log(user);
    }


    removeCourse(user,course){
        var index = user.courses.indexOf(course);
        user.courses.splice(index,1);
        console.log(user);  
    }   
}

let user1 = new User('sandeep',33,'sandeep@gmail.com')
let user2 = new User('vishnu',24,'v@gmai.com')
let user3 = new Moderator('sagar',24,'sagar@gmail.com');
let user4 = new Admin('parul',25,'p@gmail.com');
let users = [user1,user2,user3,user4];

users.forEach(element => {
    console.log(element);
});

user1.login();
user1.logout();
user3.addCoins();
user3.removeCoins();
user4.addCourse(user1,'Javascript');
user4.removeCourse(user1,'Javascript');



