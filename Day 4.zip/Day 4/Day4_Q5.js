var earn = Number(prompt("Enter the Sales made by you this year:"));

if (earn==NaN)
     console.log("Oops!!! Invalid Entry");
else if (earn>=0 && earn<=5000)
    console.log(`Your commission for this year is Rs. ${(earn*2)/100}`);
else if (earn>5000 && earn<=10000)
    console.log(`Your commission for this year is Rs. ${(earn*5)/100}`);
else if (earn>10000 && earn<=20000)
    console.log(`Your commission for this year is Rs. ${(earn*7)/100}`);
else
    console.log(`Your commission for this year is Rs. ${(earn*10)/100}`);