var earn = Number(prompt("Enter the Sales made by you this year:"));

if (earn==NaN)
     console.log("Oops!!! Invalid Entry");
else if (earn>=0 && earn<=5000){
    total_commission = earn*.02;
    console.log(`Your commission for this year is Rs. ${total_commission}`);}
else if (earn>5000 && earn<=10000){
    total_commission = 5000*.02+(earn-5000)*.05;
    console.log(`Your commission for this year is Rs. ${total_commission}`);}
else if (earn>10000 && earn<=20000){
    total_commission = 5000*.02+5000*.05+(earn-10000)*.07;
    console.log(`Your commission for this year is Rs. ${total_commission}`);}
else{
    total_commission = 5000*.02+5000*.05+10000*.07+(earn-20000)*0.1;
    console.log(`Your commission for this year is Rs. ${total_commission}`);}