// // //replace function

// function ask(question,yes,no){
//     if(confirm(question)) yes()
//     else no()
// }

// ask(
//     "Do You Agree?",
//     function(){alert("you agreed.");},
//     function(){alert("You cancelled the execution.");}
// )

//--------solution

function ask(question,yes,no){
    if(confirm(question)) yes()
    else no()
}

ask(
    "Do you Agree?",
    () => alert("You agreed."),
    () => alert("You canceled the execution.")
)