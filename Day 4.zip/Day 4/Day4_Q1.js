//1

for ( let i =1;i<101;i++){

    if (i%3==0 && i%5==0)
        console.log(`value of loop is ${i} so FizzBuzz`)
    else if (i%3==0)
    console.log(`value of loop is ${i} so Fizz`)
    else if(i%5==0)
    console.log(`value of loop is ${i} so Buzz`)
}