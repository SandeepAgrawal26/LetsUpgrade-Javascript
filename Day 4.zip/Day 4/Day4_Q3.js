var shoppingList = ['Apple','Milk','Rice','Flour','Egg','Coffee'];
//console.log("Shopping List are " + shoppingList);
console.log(shoppingList);
var shoppingbasket = [...shoppingList,"Bread","Butter"];
console.log(shoppingbasket);