const student = {
    name: "helsinki",
    age: 24,
    projects: {
        diceGame: "Two player dice game using Javascript"
    },
}

const {name, age,projects:{diceGame}} = student;
console.log ("Name =>  " +name +"\n","Age =>  " + age + "\n", "DiceGame =>  " +diceGame);
    
