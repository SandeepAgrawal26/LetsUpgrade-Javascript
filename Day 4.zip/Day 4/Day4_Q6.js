let check = Number(prompt("Enter Number Greater than 100"));

while(true){
    if (check>100||check==""){
        console.log("Good Job!!, You are Exited")
        break;
    }
    else
        check = Number(prompt("Enter Number Greater than 100"));
}