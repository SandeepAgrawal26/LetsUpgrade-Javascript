
let choice = Number(prompt("Choose operation you want to perform for 2 Number" +"\n" + "1. Addition"+"\n"+"2.Subtraction"
+"\n"+"3.Multiplication"+"\n" + "4.Division"+"\n" + "5.Square Root"+"\n"+"6.Percentage"))

if (choice<1 || choice>6 || choice ==NaN){
    console.log("Oops!!! Invalid Entry");
}

else {
    switch(choice){

        case 1:
           let num1 = Number(prompt("Enter the First Number for Addition "));
           let num2 = Number(prompt("Enter the Second Number for Addition"));
          if (num1 ==NaN || num2==NaN){
              console.log("Please Input Numeric value")
          }
               result = num1 + num2;
               console.log(`Addition of number ${num1} and ${num2} is ${result}`);
               break;
       case 2:
           let num3 = Number(prompt("Enter the First Number for Subtraction "));
           let num4 = Number(prompt("Enter the Second Number for Subtraction"));
           if (num3 ==NaN || num4==NaN){
               console.log("Please Input Numeric value")
           }
               result = num3 - num4;
               console.log(`Subtraction of number ${num3} and ${num4} is ${result}`);    
               break; 
       case 3:
           let num5 = Number(prompt("Enter the First Number for Multiplication "));
           let num6 = Number(prompt("Enter the Second Number for Multiplication"));
           if (num5 ==NaN || num6==NaN){
               console.log("Please Input Numeric value")
           }
               result = num5 * num6;
               console.log(`Multiplication of number ${num5} and ${num6} is ${result}`);    
               break;   

       case 4:
           let num7 = Number(prompt("Enter the First Number for Division "));
           let num8 = Number(prompt("Enter the Second Number for Division"));
           if (num7 ==NaN || num8==NaN){
               console.log("Please Input Numeric value")
           }
               result = num7 / num8;
               console.log(`Division Value of number ${num7} by ${num8} is ${result}`);    
               break;   
       case 5:
           let num9 = Number(prompt("Enter the Number to get the Square Root Value "));
           if (num9 ==NaN){
               console.log("Please Input Numeric value")
           }
               console.log(`Square Root of  ${num9} is ${Math.sqrt(num9)}`);    
               break; 
       case 6:
           let var1 = Number(prompt("Enter the Number for which percantage has to be Calculated "));
           let var2 = Number(prompt("Enter the Number for How much Percent you want to calculate"));
           if (var1 ==NaN || var2==NaN){
               console.log("Please Input Numeric value")
           }
               result = (var1*var2)/100;
               console.log(`Value of ${var2} Percent of Number ${var1}  is ${result}`);  
               break; 
       

    }
}