// Question 3:
// Write a program to generate a quote randomly and display it on the web page in a proper format.

var quote,author,index;

async function GenerateQuote(){
    const response= await fetch("https://type.fit/api/quotes");
    const data = await response.json();
    //console.log(data)

       index = Math.floor(Math.random()*data.length);
        quote = data[index].text;
        author = data[index].author;

    
    document.getElementById("qu").innerText=quote;
    if (document.getElementById("auth").innerText=="")
        document.getElementById("auth").innerText = "Author is Unknown"
    else
        document.getElementById("auth").innerText=author;
}
