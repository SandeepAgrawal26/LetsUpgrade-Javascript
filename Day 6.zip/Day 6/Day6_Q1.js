// Question 1:
// Write a program that will iterate over an array of colors and change the background of the page
// after 5 seconds.




var arr = ['orange','yellow','blue','green','pink','red'];
var index =0;

const col = document.querySelector('#list');

function changeColor() {
    document.bgColor = arr[index];
   col.innerHTML=arr[index];
    index = (index + 1) % arr.length;
    
  }

setInterval(changeColor,5000);