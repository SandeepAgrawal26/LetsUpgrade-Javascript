// Question 3:
// Make a webpage that will ask the name of the user. Then will display a welcome message on the
// webpage. Also the webpage should also have a clock.
// Using the toggle method of classList add a dark mode feature to the website

const name = prompt("Please Enter Your Name","Anonymous");
title.innerHTML = `Welcome,  ${name} !!!`;

const timer = document.getElementById('time');

function clock(){
    let date = new Date();
    let time = date.toLocaleTimeString();
    timer.innerText = time;
}
setInterval(clock,1000);

const sc = document.getElementById('classStyle');
sc.classList.toggle('changebck');