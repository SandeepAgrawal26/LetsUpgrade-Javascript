// Question 2:
// Write a program that will display the multiplication table of a number on the webpage in a proper
// format. Take the input from the user.
// Input - 5
// Output - 5 x 1 = 5
//  5 x 2 = 10
//  and so on…

var a = prompt("ENTER THE NUMBER");
        let col = document.getElementById("test");
        col.innerHTML = `NUMBER ENTERED BY THE USER = ` + input();
        function input() {
            if (a > 0)
                return a;
            else
                return null;
        }
        const list = document.querySelector('#list');
        for (let i = 1; i <= 10; i++) {
            list.innerHTML += `<li>${a} x ${i} = ${a * i} </li>`;
        }