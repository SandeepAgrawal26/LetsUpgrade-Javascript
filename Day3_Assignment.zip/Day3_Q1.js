//Question 1 - Take a number from a user and write a function which checks whether the number is even or odd. 
//Assign the result to a variable and log that variable in the console.
//-------------------------------Example Input: 23     Output: The number entered is 23 and Number is odd

function numberInput(num){
    let result = (num%2==0)?`The Number entered is ${num} and Number is Even`:
    `The Number entered is ${num} and Number is Odd`
    console.log(result);
}

let userInput = Number(prompt("Enter the number:"));
numberInput(userInput);