//Assignment 



//**************************************************************************************************************** */
//Question 3 - Write a program to take marks as input from the user and grade him accordingly. Use Conditional
//statements. Also the same code using switch or ternary
//input: 50 -----------------------------------------------------Output : Marks are 50 and grade is B
////dummy data range >90 A+, 75 - 90 A, 60-74 B+, 40-59 B, 30-39 C , else D

//  1 Conditional Statement
let marks = Number(prompt("Enter the mark:"));

if (marks==null || marks>100 || marks<=0){
    console.log("Please Enter marks between 1 and 100")
}
else{
    
    if (marks>30 && marks <40)
        console.log(`The marks entered is ${marks} and Grade is C`)
    else if (marks>=40 && marks <60)
        console.log(`The marks entered is ${marks} and Grade is B`)
    else if (marks>=60 && marks <75)
        console.log(`The marks entered is ${marks} and Grade is B+`)
    else if (marks>=75 && marks<90)
        console.log(`The marks entered is ${marks} and Grade is A`)
    else if(marks>=90)
        console.log(`The marks entered is ${marks} and Grade is A+`)
    else
        console.log(`The marks entered is ${marks} and Grade is D`)
}

//  1 Ternary 
////dummy data range 0-55 grade B an 55-100


let marks = Number(prompt("Enter the mark:"));

if (marks==null || marks>100 || marks<=0){
    console.log("Please Enter marks between 1 and 100")
}
else{
        let grade = (marks>30 && marks <40)?`The marks entered is ${marks} and Grade is C`:
        (marks>=40 && marks <60)?`The marks entered is ${marks} and Grade is B`:
        (marks>=60 && marks <75)?`The marks entered is ${marks} and Grade is B+`:
        (marks>=75 && marks<90)?`The marks entered is ${marks} and Grade is A`:
        (marks>=90)?`The marks entered is ${marks} and Grade is A+`:
        `The marks entered is ${marks} and Grade is D`
        console.log(grade);

}