//Question 2- Write a program which will take OS name and version from the user separated by a space. Then
//log the OS name and version on the console.
//Input: "Android 9" --------------------------------------------Output: The OS name is Android and version is 9


function osVersion(str){
    let var1 = str.split(" ")
    
        if (var1[1]!=Number)
            console.log("Please enter correct version of the OS")
        else
            console.log(`The OS name is ${var1[0]} and version is ${var1[1]}`);
    }
    
    let userInput = prompt("Enter the OS version:");
    
    if (userInput=="")
        console.log("Please Enter version of the OS")
    else
        osVersion(userInput);